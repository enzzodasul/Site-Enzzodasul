import { mockVideos } from '../data/mockData';
import { Video } from '../types';

export const youtubeService = {
  async getVideos(category?: Video['category']): Promise<Video[]> {
    await new Promise((resolve) => setTimeout(resolve, 100));
    if (category) {
      return mockVideos.filter((v) => v.category === category);
    }
    return mockVideos;
  },

  async getFeaturedVideo(): Promise<Video | undefined> {
    await new Promise((resolve) => setTimeout(resolve, 50));
    return mockVideos.find((v) => v.featured) || mockVideos[0];
  },
};
