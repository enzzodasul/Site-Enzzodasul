import React from 'react';
import { motion } from 'framer-motion';
import { Play, MapPin, ChevronDown, Radio } from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { useAudio } from '../../context/AudioContext';
import { mockSongs } from '../../data/mockData';

interface HeroSectionProps {
  onNavigate: (tab: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate }) => {
  const { playSong, isPlaying, currentTrack } = useAudio();

  const handlePlayHeroTrack = () => {
    if (mockSongs.length > 0) {
      playSong(mockSongs[0]);
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
      {/* Background Cinematic Atmosphere */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2000&q=80"
          alt="Enzzo da Sul Stage Atmosphere"
          className="w-full h-full object-cover object-center opacity-30 filter contrast-125 saturate-50 scale-105 animate-float"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background" />
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(var(--color-surface-border)_1px,transparent_1px)] [background-size:32px_32px] opacity-40" />
      </div>

      {/* Main Hero Content */}
      <div className="relative z-10 max-w-site mx-auto px-4 sm:px-6 flex flex-col items-center text-center">
        
        {/* Top Tag & Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-wrap items-center justify-center gap-3 mb-6"
        >
          <Badge variant="accent">PLATAFORMA DIGITAL OFICIAL</Badge>
          <Badge variant="live">AO VIVO SUL TOUR 2026</Badge>
        </motion.div>

        {/* Giant Main Title */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-hero font-display font-black uppercase tracking-tighter text-text leading-none select-none drop-shadow-2xl"
        >
          ENZZO <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-text to-accent">DA SUL</span>
        </motion.h1>

        {/* Tagline Concept */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-4 text-base sm:text-2xl font-display uppercase tracking-widest text-text-muted max-w-3xl font-medium"
        >
          MUSIC THAT TRAVELS <span className="text-accent">•</span> MÚSICA QUE ATRAVESSA LUGARES
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-3 text-xs sm:text-sm font-mono text-text-dim max-w-xl"
        >
          Explore o universo sonoro, as apresentações marcantes, o mapa da carreira e as conexões artísticas de Enzzo da Sul.
        </motion.p>

        {/* Hero CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <Button
            variant="glow"
            size="lg"
            onClick={handlePlayHeroTrack}
            className="flex items-center gap-3"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>{isPlaying && currentTrack?.id === mockSongs[0].id ? 'Ouvindo Agora' : 'Ouvir Lançamento'}</span>
          </Button>

          <Button
            variant="secondary"
            size="lg"
            onClick={() => {
              onNavigate('world');
              document.getElementById('world')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex items-center gap-2"
          >
            <MapPin className="w-5 h-5 text-accent" />
            <span>Explorar Mapa</span>
          </Button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="mt-16 sm:mt-24 flex flex-col items-center gap-2 cursor-pointer group"
          onClick={() => {
            document.getElementById('music')?.scrollIntoView({ behavior: 'smooth' });
          }}
        >
          <span className="text-[10px] font-mono text-text-dim uppercase tracking-widest group-hover:text-accent transition-colors">
            SCROLL TO EXPLORE
          </span>
          <ChevronDown className="w-5 h-5 text-accent animate-bounce" />
        </motion.div>
      </div>
    </section>
  );
};
