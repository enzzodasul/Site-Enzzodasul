import React from 'react';
import { Disc3, Instagram, Youtube, Music2, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#040405] border-t border-surface-border pt-16 pb-28 sm:pb-16 text-text-muted">
      <div className="max-w-site mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-surface-border">
          {/* Column 1: Artist Identity */}
          <div className="md:col-span-2 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-accent/20 border border-accent flex items-center justify-center">
                <Disc3 className="w-6 h-6 text-accent animate-spin-slow" />
              </div>
              <span className="text-2xl font-display font-black text-white tracking-wider">
                ENZZO DA SUL
              </span>
            </div>
            <p className="text-xs font-mono uppercase tracking-widest text-accent font-semibold">
              MUSIC • LIVE • WORLD
            </p>
            <p className="text-sm text-text-muted leading-relaxed max-w-md">
              Plataforma oficial do artista musical Enzzo da Sul. Conectando música, performances ao vivo, turnês globais e produções visuais contemporâneas.
            </p>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-mono text-text uppercase tracking-widest font-bold">
              Navegação
            </h4>
            <ul className="flex flex-col gap-2 text-sm">
              {['home', 'music', 'live', 'world', 'connections', 'watch', 'moments', 'booking'].map((tab) => (
                <li key={tab}>
                  <button
                    onClick={() => {
                      onNavigate(tab);
                      document.getElementById(tab)?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-accent transition-colors uppercase tracking-wider text-xs font-mono"
                  >
                    {tab}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Social & External */}
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-mono text-text uppercase tracking-widest font-bold">
              Plataformas
            </h4>
            <ul className="flex flex-col gap-2 text-sm">
              <li>
                <a
                  href="https://spotify.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-accent transition-colors text-xs font-mono"
                >
                  <Music2 className="w-4 h-4 text-accent" />
                  <span>Spotify</span>
                  <ArrowUpRight className="w-3 h-3 text-text-dim" />
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-accent transition-colors text-xs font-mono"
                >
                  <Instagram className="w-4 h-4 text-accent" />
                  <span>Instagram</span>
                  <ArrowUpRight className="w-3 h-3 text-text-dim" />
                </a>
              </li>
              <li>
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-accent transition-colors text-xs font-mono"
                >
                  <Youtube className="w-4 h-4 text-accent" />
                  <span>YouTube</span>
                  <ArrowUpRight className="w-3 h-3 text-text-dim" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & attribution */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-text-dim">
          <p>© {new Date().getFullYear()} ENZZO DA SUL. Todos os direitos reservados.</p>
          <p className="flex items-center gap-2">
            <span>PLATAFORMA DIGITAL OFICIAL</span>
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <span>ENZZO DA SUL UNIVERSE</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
