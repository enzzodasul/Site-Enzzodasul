import React, { useEffect, useState } from 'react';
import { SectionHeading } from '../ui/SectionHeading';
import { VideoModal } from './VideoModal';
import { Video } from '../../types';
import { youtubeService } from '../../services/youtubeService';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Play } from 'lucide-react';
import { formatNumber } from '../../utils/formatters';

export const WatchSection: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [activeCategory, setActiveCategory] = useState<Video['category'] | 'ALL'>('ALL');

  useEffect(() => {
    youtubeService.getVideos().then(setVideos);
  }, []);

  const categories: Array<Video['category'] | 'ALL'> = ['ALL', 'LIVE', 'MUSIC', 'BACKSTAGE', 'MOMENTS'];

  const filteredVideos =
    activeCategory === 'ALL'
      ? videos
      : videos.filter((v) => v.category === activeCategory);

  return (
    <section id="watch" className="py-20 sm:py-28 relative">
      <div className="max-w-site mx-auto px-4 sm:px-6">
        <SectionHeading
          tag="VÍDEOS & PERFORMANCE"
          title="WATCH EXPERIENCE"
          subtitle="Videoclipes oficiais, apresentações ao vivo e registros documentais de bastidores."
        />

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded-lg border transition-all ${
                activeCategory === cat
                  ? 'bg-accent text-white border-accent shadow-glow font-bold'
                  : 'bg-surface text-text-muted border-surface-border hover:text-text hover:bg-surface-hover'
              }`}
            >
              {cat === 'ALL' ? 'Todos' : cat}
            </button>
          ))}
        </div>

        {/* Video Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <Card
              key={video.id}
              onClick={() => setSelectedVideo(video)}
              className="cursor-pointer group flex flex-col p-0 overflow-hidden"
            >
              <div className="relative aspect-video w-full overflow-hidden">
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-accent text-white flex items-center justify-center shadow-glow group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>
                <div className="absolute top-3 left-3">
                  <Badge variant="accent">{video.category}</Badge>
                </div>
                <div className="absolute bottom-3 right-3 px-2 py-0.5 bg-black/80 text-[10px] font-mono text-white rounded">
                  {video.duration}
                </div>
              </div>

              <div className="p-5 flex flex-col gap-2 text-left">
                <h4 className="text-base font-display font-bold text-text line-clamp-2 group-hover:text-accent transition-colors">
                  {video.title}
                </h4>
                <span className="text-xs font-mono text-text-dim">
                  {formatNumber(video.views)} VISUALIZAÇÕES
                </span>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <VideoModal
        video={selectedVideo}
        isOpen={!!selectedVideo}
        onClose={() => setSelectedVideo(null)}
      />
    </section>
  );
};
