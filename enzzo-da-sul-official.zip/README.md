# ENZZO DA SUL — Plataforma Digital Oficial

Plataforma digital oficial do artista musical **ENZZO DA SUL**, desenvolvida com React, TypeScript, Vite e Tailwind CSS.

## 🚀 Como Executar o Projeto

1. Instalar as dependências:
```bash
npm install
```

2. Iniciar o servidor de desenvolvimento:
```bash
npm run dev
```

3. Abrir no navegador:
[http://localhost:3000](http://localhost:3000)

## 📦 Como Gerar o Build de Produção

```bash
npm run build
```

Os arquivos compilados estarão na pasta `dist/`.

## 🎨 Identidade Visual e CSS Variables

Todas as variáveis globais de estilo (cores, tipografia, bordas, transições) estão centralizadas em:
`src/styles/variables.css`

Para alterar a cor de destaque global de todo o site, basta modificar a variável `--color-accent`.

---
© ENZZO DA SUL. Todos os direitos reservados.
