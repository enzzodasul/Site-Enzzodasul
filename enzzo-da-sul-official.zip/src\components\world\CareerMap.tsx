import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Location } from '../../types';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface CareerMapProps {
  locations: Location[];
  onSelectLocation: (location: Location) => void;
}

// Custom Leaflet Pulsing Neon HTML Marker
const createCustomIcon = (showsCount: number) => {
  return L.divIcon({
    className: 'custom-map-pin-wrapper',
    html: `
      <div class="relative flex items-center justify-center">
        <span class="absolute w-8 h-8 rounded-full bg-accent/40 animate-ping"></span>
        <div class="relative w-7 h-7 rounded-full bg-accent text-white flex items-center justify-center font-mono font-bold text-xs shadow-glow border-2 border-white">
          ${showsCount}
        </div>
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
};

export const CareerMap: React.FC<CareerMapProps> = ({
  locations,
  onSelectLocation,
}) => {
  const centerLat = -26.5;
  const centerLng = -50.5;

  return (
    <div className="relative w-full h-[450px] sm:h-[550px] rounded-2xl overflow-hidden border border-surface-border shadow-2xl">
      <MapContainer
        center={[centerLat, centerLng]}
        zoom={4}
        scrollWheelZoom={false}
        className="w-full h-full z-10"
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution=""
        />

        {locations.map((loc) => (
          <Marker
            key={loc.id}
            position={[loc.latitude, loc.longitude]}
            icon={createCustomIcon(loc.showsCount)}
            eventHandlers={{
              click: () => onSelectLocation(loc),
            }}
          >
            <Popup className="custom-leaflet-popup">
              <div className="p-2 flex flex-col gap-2 text-left bg-surface text-text rounded-lg border border-surface-border">
                <span className="font-display font-bold text-sm text-text">
                  {loc.city}, {loc.country}
                </span>
                <span className="text-xs font-mono text-accent">
                  {loc.showsCount} {loc.showsCount === 1 ? 'Apresentação' : 'Apresentações'}
                </span>
                <button
                  onClick={() => onSelectLocation(loc)}
                  className="mt-1 px-3 py-1 bg-accent text-white font-mono text-[10px] uppercase tracking-wider rounded font-bold hover:bg-accent-hover"
                >
                  Ver Histórico
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};
