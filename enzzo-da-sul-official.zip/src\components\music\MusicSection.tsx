import React, { useEffect, useState } from 'react';
import { SectionHeading } from '../ui/SectionHeading';
import { SongCard } from './SongCard';
import { Song } from '../../types';
import { spotifyService } from '../../services/spotifyService';

export const MusicSection: React.FC = () => {
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    spotifyService.getTopSongs().then((data) => {
      setSongs(data);
      setLoading(false);
    });
  }, []);

  return (
    <section id="music" className="py-20 sm:py-28 relative">
      <div className="max-w-site mx-auto px-4 sm:px-6">
        <SectionHeading
          tag="CATÁLOGO MUSICAL"
          title="THE SOUND OF THE SOUTH"
          subtitle="Músicas mais tocadas e produções mais populares em todas as plataformas."
        />

        {loading ? (
          <div className="flex flex-col gap-4 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 bg-surface rounded-xl border border-surface-border" />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {songs.map((song, idx) => (
              <SongCard key={song.id} song={song} rank={idx + 1} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
