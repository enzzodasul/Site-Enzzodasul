import { Song, Show, Artist, Location, Video, GalleryItem, SocialPost, CareerStats, Connection } from '../types';

export const mockCareerStats: CareerStats = {
  shows: 48,
  cities: 18,
  countries: 3,
  streams: 1250000,
  collaborations: 14,
};

export const mockSongs: Song[] = [
  {
    id: 'song-1',
    title: 'Visão da Sul',
    artist: 'ENZZO DA SUL',
    featuredArtists: ['[DADOS REAIS NECESSÁRIOS]'],
    album: 'Single',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    duration: '3:24',
    plays: 450000,
    featured: true,
    releaseYear: 2025,
    spotifyUrl: 'https://spotify.com',
    youtubeUrl: 'https://youtube.com',
    waveform: [15, 30, 45, 80, 60, 90, 75, 40, 65, 85, 95, 70, 50, 80, 60, 40, 30, 85, 90, 100, 65, 45, 20, 10]
  },
  {
    id: 'song-2',
    title: 'Horizonte Frio',
    artist: 'ENZZO DA SUL',
    featuredArtists: ['Artista X'],
    album: 'EP Travessia',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    duration: '3:50',
    plays: 320000,
    featured: true,
    releaseYear: 2025,
    spotifyUrl: 'https://spotify.com',
    youtubeUrl: 'https://youtube.com',
    waveform: [20, 40, 60, 50, 70, 80, 90, 85, 60, 75, 80, 95, 60, 40, 50, 70, 85, 90, 60, 40, 30, 20]
  },
  {
    id: 'song-3',
    title: 'Noite sem Fim',
    artist: 'ENZZO DA SUL',
    album: 'Single',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    duration: '2:45',
    plays: 210000,
    featured: false,
    releaseYear: 2024,
    spotifyUrl: 'https://spotify.com',
    waveform: [30, 50, 70, 90, 100, 85, 70, 60, 80, 90, 75, 55, 40, 60, 80, 70, 50, 30]
  },
  {
    id: 'song-4',
    title: 'Código Urbano',
    artist: 'ENZZO DA SUL',
    featuredArtists: ['Produtor Y'],
    album: 'Código Urbano',
    coverUrl: 'https://images.unsplash.com/photo-1598387993441-a364f854c3e1?auto=format&fit=crop&w=800&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    duration: '3:12',
    plays: 180000,
    featured: false,
    releaseYear: 2024,
    spotifyUrl: 'https://spotify.com',
    waveform: [25, 45, 65, 85, 75, 95, 60, 70, 85, 90, 65, 50, 70, 80, 60, 45, 30]
  }
];

export const mockShows: Show[] = [
  {
    id: 'show-1',
    title: 'Festival Sul Conecta 2026',
    venue: 'Espaço Hall Urbano',
    city: 'Porto Alegre',
    state: 'RS',
    country: 'Brasil',
    date: '2026-10-15',
    time: '22:00',
    ticketStatus: 'available',
    ticketUrl: 'https://sympla.com.br',
    isNext: true,
    description: 'Apresentação principal no festival de música urbana contemporânea.',
    coverImage: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    latitude: -30.0346,
    longitude: -51.2177
  },
  {
    id: 'show-2',
    title: 'Noite Futurista - Turnê Travessia',
    venue: 'Club Subterrâneo',
    city: 'Curitiba',
    state: 'PR',
    country: 'Brasil',
    date: '2026-11-02',
    time: '23:30',
    ticketStatus: 'available',
    ticketUrl: 'https://sympla.com.br',
    coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    latitude: -25.4284,
    longitude: -49.2733
  },
  {
    id: 'show-3',
    title: 'São Paulo Audio Night',
    venue: 'Audio Club',
    city: 'São Paulo',
    state: 'SP',
    country: 'Brasil',
    date: '2026-11-20',
    time: '21:00',
    ticketStatus: 'coming_soon',
    coverImage: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=800&q=80',
    latitude: -23.5505,
    longitude: -46.6333
  },
  {
    id: 'show-4',
    title: 'Rio Urban Showcase',
    venue: 'Circo Voador',
    city: 'Rio de Janeiro',
    state: 'RJ',
    country: 'Brasil',
    date: '2026-12-05',
    time: '22:00',
    ticketStatus: 'sold_out',
    coverImage: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=800&q=80',
    latitude: -22.9068,
    longitude: -43.1729
  }
];

export const mockLocations: Location[] = [
  {
    id: 'loc-poa',
    city: 'Porto Alegre',
    state: 'RS',
    country: 'Brasil',
    latitude: -30.0346,
    longitude: -51.2177,
    showsCount: 14,
    lastPerformance: '2025-12-18',
    events: ['Sul Conecta 2025', 'Opinião Stage Live', 'Festival Auditório'],
    notes: 'Berço da caminhada artística de Enzzo da Sul com apresentações lendárias.'
  },
  {
    id: 'loc-cba',
    city: 'Curitiba',
    state: 'PR',
    country: 'Brasil',
    latitude: -25.4284,
    longitude: -49.2733,
    showsCount: 8,
    lastPerformance: '2025-11-10',
    events: ['Curitiba Soundwave', 'Opera de Arame Night'],
    notes: 'Público com conexão única e energia vibrante em todas as edições.'
  },
  {
    id: 'loc-sp',
    city: 'São Paulo',
    state: 'SP',
    country: 'Brasil',
    latitude: -23.5505,
    longitude: -46.6333,
    showsCount: 12,
    lastPerformance: '2026-01-22',
    events: ['Audio SP', 'Cine Joia Sessions', 'SubSolo 2025'],
    notes: 'Palco de encontros com produtores nacionais e gravação de videoclipes.'
  },
  {
    id: 'loc-rj',
    city: 'Rio de Janeiro',
    state: 'RJ',
    country: 'Brasil',
    latitude: -22.9068,
    longitude: -43.1729,
    showsCount: 6,
    lastPerformance: '2025-09-30',
    events: ['Circo Voador Sessions', 'Lapa Underground'],
    notes: 'Colaborações gravadas nos estúdios da zona sul carioca.'
  },
  {
    id: 'loc-fln',
    city: 'Florianópolis',
    state: 'SC',
    country: 'Brasil',
    latitude: -27.5954,
    longitude: -48.5480,
    showsCount: 5,
    lastPerformance: '2026-02-14',
    events: ['Floripa Summer Beats', 'Lagoa Sessions'],
    notes: 'Apresentações acústicas e eletrizantes durante a temporada.'
  },
  {
    id: 'loc-bue',
    city: 'Buenos Aires',
    state: 'BA',
    country: 'Argentina',
    latitude: -34.6037,
    longitude: -58.3816,
    showsCount: 3,
    lastPerformance: '2025-10-12',
    events: ['Niceto Club International', 'Palermo Underground'],
    notes: 'Primeiro show internacional expandindo o som da Sul pela América Latina.'
  }
];

export const mockArtists: Artist[] = [
  {
    id: 'artist-enzzo',
    name: 'ENZZO DA SUL',
    role: 'Artist',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    bio: 'Artista musical unindo sonoridade contemporânea, lírica visceral e beats urbanos futuristas.',
    collaborationsCount: 14,
    sharedTracks: ['song-1', 'song-2', 'song-3', 'song-4']
  },
  {
    id: 'artist-x',
    name: 'Artista X',
    role: 'Featured',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    bio: 'Vocalista e compositor expoente na cena sulista.',
    spotifyUrl: 'https://spotify.com',
    instagramUrl: 'https://instagram.com',
    collaborationsCount: 3,
    sharedTracks: ['song-2']
  },
  {
    id: 'artist-prod-y',
    name: 'Produtor Y',
    role: 'Producer',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    bio: 'Beatmaker e produtor musical focado em timbres sintéticos e graves pesados.',
    instagramUrl: 'https://instagram.com',
    collaborationsCount: 5,
    sharedTracks: ['song-4']
  },
  {
    id: 'artist-comp-z',
    name: 'Compositor Z',
    role: 'Composer',
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=400&q=80',
    bio: 'Compositor e arranjador de trilhas urbanas.',
    collaborationsCount: 2,
    sharedTracks: ['song-1']
  }
];

export const mockConnections: Connection[] = [
  {
    id: 'conn-1',
    fromArtistId: 'artist-enzzo',
    toArtistId: 'artist-x',
    relationship: 'Featured',
    trackTitle: 'Horizonte Frio'
  },
  {
    id: 'conn-2',
    fromArtistId: 'artist-enzzo',
    toArtistId: 'artist-prod-y',
    relationship: 'Producer',
    trackTitle: 'Código Urbano'
  },
  {
    id: 'conn-3',
    fromArtistId: 'artist-enzzo',
    toArtistId: 'artist-comp-z',
    relationship: 'Composer',
    trackTitle: 'Visão da Sul'
  }
];

export const mockVideos: Video[] = [
  {
    id: 'vid-1',
    title: 'ENZZO DA SUL — Visão da Sul (Clipe Oficial)',
    category: 'MUSIC',
    youtubeId: 'dQw4w9WgXcQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    views: 185000,
    duration: '3:45',
    featured: true
  },
  {
    id: 'vid-2',
    title: 'ENZZO DA SUL — Live at Circo Voador 2025 (Full Experience)',
    category: 'LIVE',
    youtubeId: 'dQw4w9WgXcQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    views: 94000,
    duration: '18:20',
    featured: true
  },
  {
    id: 'vid-3',
    title: 'Bastidores da Turnê Travessia — Documentário Curto',
    category: 'BACKSTAGE',
    youtubeId: 'dQw4w9WgXcQ',
    thumbnailUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    views: 42000,
    duration: '8:15',
    featured: false
  }
];

export const mockGallery: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Luzes do Palco Principal',
    imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=1000&q=80',
    aspectRatio: 'landscape',
    city: 'Porto Alegre',
    event: 'Sul Conecta',
    date: '2025-12-18',
    category: 'SHOWS'
  },
  {
    id: 'gal-2',
    title: 'Foco antes da Entrada',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'portrait',
    city: 'Curitiba',
    event: 'Turnê Travessia',
    date: '2025-11-10',
    category: 'BACKSTAGE'
  },
  {
    id: 'gal-3',
    title: 'Sessão de Gravação de Beats',
    imageUrl: 'https://images.unsplash.com/photo-1598387993441-a364f854c3e1?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'square',
    city: 'São Paulo',
    event: 'Estúdio SubSolo',
    date: '2026-01-20',
    category: 'STUDIO'
  },
  {
    id: 'gal-4',
    title: 'Multidão em Transe',
    imageUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1000&q=80',
    aspectRatio: 'landscape',
    city: 'Rio de Janeiro',
    event: 'Circo Voador',
    date: '2025-09-30',
    category: 'SHOWS'
  }
];

export const mockPosts: SocialPost[] = [
  {
    id: 'post-1',
    caption: 'Que noite insana Porto Alegre! Energia inexplicável do primeiro ao último verso. Valeu cada segundo! ⚡',
    imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    postUrl: 'https://instagram.com',
    likes: 12400,
    comments: 480,
    date: 'Há 2 dias',
    category: 'SHOWS'
  },
  {
    id: 'post-2',
    caption: 'No estúdio finalizando o próximo single. O som tá tomando uma forma surpreendente... Prontos pra isso?',
    imageUrl: 'https://images.unsplash.com/photo-1598387993441-a364f854c3e1?auto=format&fit=crop&w=800&q=80',
    postUrl: 'https://instagram.com',
    likes: 9800,
    comments: 310,
    date: 'Há 5 dias',
    category: 'MUSIC'
  },
  {
    id: 'post-3',
    caption: 'Bastidores da gravação em SP com a rapaziada. Conexão real fortalece a caminhada.',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80',
    postUrl: 'https://instagram.com',
    likes: 8500,
    comments: 205,
    date: 'Há 1 semana',
    category: 'BACKSTAGE'
  }
];
